# i=0*
# i=1* *
# i=2* * *
# i=3* * * *
# i=4* * * * *

n=5
# for i in range(n):
#     for j in range(i+1):
#         print("*",end = ' ')
#     print()

# i=0* * * * * 
# i=1* * * *
# i=2* * *
# i=3* *
# i=4*

# for i in range(n):
#     for j in range(i,n):
#         print("*",end = ' ')

#     print()


#         *
#       * *
#     * * * 
#   * * * * 
# * * * * * 


# for i in range(n):
#     for j in range(i,n):
#         print(" ",end=' ')
#     for k in range(i+1):
#         print("*",end=" ")
#     print()


# * * * * *
#   * * * *
#     * * *
#       * *
#         * 

# for i in range(n):
#     for k in range(i+1):
#         print(" ",end=" ")
        
#     for j in range(i,n):
#         print("*",end=' ')
#     print()



#         *
#       * * *
#     * * * * *
#   * * * * * * * 
# * * * * * * * * *


# for i in range(n):
#     for j in range(i,n):
#         print(" ",end=" ")
#     for k in range(i):
#         print("*",end=' ')
#     for l in range(i+1):
#         print("*",end= " ")
#     print()


#   * * * * * * *
#     * * * * * 
#       * * * 
#         * 

# for i in range(n):
#     for j in range(i+1):
#         print(" ",end=' ')
#     for k in range(i,n-1):
#         print("*",end=" ")
#     for l in range(i,n):
#         print("*",end=" ")
#     print()


#     * * * * *
#    * * * * *
#   * * * * *
#  * * * * *
# * * * * *


# for i in range(n):
#     for j in range(i,n-1):
#         print(" ",end=" ")
#     for k in range(n):
#         print("*",end=" ")
        
#     print()


#   * * * * * * *     |     1 2 3 4 5 6 7     |     A B C D E F G
#     * * * * *       |       1 2 3 4 5       |       A B C D E
#       * * *         |         1 2 3         |         A B C 
#         *           |           1           |           A
#       * * *         |         1 2 3         |         A B C
#     * * * * *       |       1 2 3 4 5       |       A B C D E
#   * * * * * * *     |     1 2 3 4 5 6 7     |     A B C D E F G
# * * * * * * * * *   |   1 2 3 4 5 6 7 8 9   |   A B C D E F G H 


# for i in range(n-2):
#     for j in range(i+2):
#         print(" ",end=" ")
#     for k in range(i,n-3):
#         print("*",end=" ")
#     for l in range(i,n):
#         print("*",end=" ")
#     print()

# for i in range(n):
#     for j in range(i,n):
#         print(" ",end=" ")
#     for k in range(i):
#         print("*",end=" ")
#     for l in range(i+1):
#         print("*",end=" ")
#     print()


# * * * * *   |   1 2 3 4 5   |   A B C D E
# *       *   |   1       5   |   A       E
# *       *   |   1       5   |   A       E
# *       *   |   1       5   |   A       E
# * * * * *   |   1 2 3 4 5   |   A B C D E


for i in range(n):
    if i==0 or i==n-1:
        #print("hello",i)
        for i in range(n):
            print("*",end=" ")
    
    else:
        #print(i)
        for k in range(n):
            if k==0 or k==n-1:
                print("*",end=" ")
            else:
                print(" ",end=" ")
    print()
        
            
        