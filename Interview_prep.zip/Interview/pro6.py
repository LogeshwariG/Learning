#create a list of empty dictionaries

d = 10

s = [{} for _ in range(d)]
print(s)