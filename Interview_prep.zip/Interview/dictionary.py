d = {1:900, "h":2, "jk":89}

print(d.get(1))
print(d[1])
print(d.keys())
print(d.values())
print(d.items())
d.update({'jk':'hjklk'})
print(type(d.items()))

print(d.keys())
print(d.values())
print(d.get(1))
print(d.items())

for i in d:
    print(i)
    print(d[i])

# print(d.get(1))
# print(d.keys())
# print(d.values())
# print(d.items())
# d.update({"jk":"hjskjkj"})

# print("keyss")
# for i in d:
#     print(i)

# print("values")
# for i in d.values():
#     print(i)

# print("key and values")
# for i,j in d.items():
#     print(i,j)