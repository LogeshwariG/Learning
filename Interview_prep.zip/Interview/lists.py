N= [1,2,67,'hello','navya']

print(N[0],N[-1])
print(N[0:3])
N.append("new")
print("appemd",N)
N.extend([7,9,0])
print("extend",N)
N.pop(2)
print(N)
print(N.count(1))
print(N.index(1))

# print(N[0],N[-1])

# print(N[0:3])


# N.append("new")
# print("appemd", N)
# N.pop(2)
# print("pop", N)
# N.extend([12,8,65,0])
# print("extend",N)

# print(N.count(1))

# N.remove(2)
# print("remove",N)

# N.pop(4)
# print("pop", N)

# print(N.index(65))


# for i in N:
#     print(i)
