class Demo:
    def __init__(self,a,b):
        self.__a = a
        self._b = b

class Demo1(Demo):

    def output(self):
        print(self._b)


d = Demo1(3,4)
d.output()