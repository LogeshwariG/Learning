#count the number of occurences of each word in a given sentence

def counter(str):

    words = str.split()
    #print(words)

    counts = dict()

    for word in words:
        if word in counts:
            counts[word]+=1
        else:
            counts[word]=1
    return counts

print(counter("hello hello shsu iusio"))