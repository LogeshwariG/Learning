#a = "abcd"
#print(len(a))

#Find length of string without inbuilt function

def string_length(input_string):
    count = 0
    for character in input_string:
        count = count+1
    return count

print(string_length("jdeueoioeo"))






str2 = "hjhdskdlejwdewdkwdjjwkdkjwd"

count = 0
for i in str2:
    count+=1
print("count ",count)
















def string_len(input_string):
    count = 0
    for character in input_string:
        count+=1
    print("length of the string is ",count)

string_len("abcdef")