x = lambda a : a+10
print(x(78))