l1=[1,2,3,4]
l2=[2,3,45,8]

# [l1.append(x) for x in l2]
# print(l1)

print(l1+l2)