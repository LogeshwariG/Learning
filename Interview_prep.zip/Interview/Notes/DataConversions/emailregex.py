import re
text = "Please contact us at _@tutorialspoint.com for further information."+\
        " You can also give feedbacl at feedback@tp.com 10.10.10.10 255.89.10.10 "


emails = re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", text)
print(emails)


emails1 = re.findall(r"[A-Za-z0-9W+]+@[A-Za-z0-9]+\.[A-Za-z0-9]+",text)
print(emails1)

ip = re.findall(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})",text)
print(ip)