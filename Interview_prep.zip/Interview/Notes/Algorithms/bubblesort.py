def bubble_sort(input_list):
    for i in range(len(input_list)-1,0,-1):
        for j in range(i):
            if input_list[j]>input_list[j+1]:
                temp = input_list[j]
                input_list[j]= input_list[j+1]
                input_list[j+1]= temp
    print("sorted list:",input_list)
l  = [4,5,6,7,8,2]

bubble_sort(l)


for i in range(5):
    print(i)