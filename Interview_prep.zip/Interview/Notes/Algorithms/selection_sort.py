def selection_sort(input_list):
    for i in range(len(input_list)-1):
        minpos = i
        for j in range(i,len(input_list)):
            if input_list[j]<input_list[minpos]:
                minpos = j
        
        temp = input_list[i]
        input_list[i]=input_list[minpos]
        input_list[minpos] = temp

l  = [4,5,6,7,8,2]

selection_sort(l)
print(l)