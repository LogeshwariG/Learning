# check if the first and last number of a list is the same

my_list = [12,6,9,0,15]

def first_last(input_list):
    first_num = input_list[0]
    last_num = input_list[-1]

    if first_num == last_num:
        return "first and last numbers of the given list are same"
    else:
        return "first and last numbers of the given list are not same"

print(first_last(my_list))

