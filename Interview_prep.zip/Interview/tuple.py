t = (1,9,0,"jkkkll",["o","qw"])

print(t.index(9))
print(t[0:3:2])

# print(t.index(0))
# print(t[0:3:2])

# c = (1,9,7,48,0)

# print(min(c))
# print(max(c))
# print(len(c))
# print(sum(c))


# t1 = (1,9,0)
# t2 = (1,9,0)

# print(t1+t2)


# #repetation
# print(c*5)

# for i in c:
#     print(i)

# print( 1 in c)
# print ( 11 not in c)
# print( t1 is t2)

# print(t1 is not t2)