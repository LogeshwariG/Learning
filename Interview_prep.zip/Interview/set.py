s={"1",8,96,"hjs","hj","hj"}

print(s)
s.add(123)
print(s)
s.update({1,2,3,4,5,5,5})
print(s)
s.remove("1")
# print(s)
# s.add(123)
# print(s)
# s.update({1,45,779,9038,2})
# print(s)
# #s.pop()
# s.remove("1")
# print(s)


# '''
# union
# instersection
# difference 
# issubset
# issuperset
# '''

# s1={1,2,3,4,5,6}
# s2 = {1,2,3}

# # print(s1.union(s2))
# # print(s1.intersection(s2))
# # print(s1.difference(s2))
# # print(s2.difference(s1))
# # print(s1.issubset(s2))

# print(s1.issuperset(s2))
# print(s2.issubset(s1))