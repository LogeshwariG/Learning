# program to check if a key is already present in the given dictionary
#using in keyword

my_dict = {1:"j",2:"k"}

if 3 in my_dict.keys():
    print("there")
else:
    print("not there")


s1 = "Hello Hi"
reverse_string = s1[::-1]
print(reverse_string)


try:
    print(a)
except:
    print("issue")