# palindrome


input_string = "MOMyy"

def isPalindrome(input_string):
    return input_string==input_string[::-1]

print(isPalindrome(input_string))