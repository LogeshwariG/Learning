#Function that calculate the number of upper and lower case letters.

def string_finder(string_input):
    d = {'Upper_case':0,"Lower_case":0}
    for character in string_input:
        if character.isupper():
            d['Upper_case']+=1
        elif character.islower():
            d['Lower_case']+=1
        else:
            pass
        
    return d

print(string_finder("HfdtXjioH"))


def up_low(input_string):
    d = {'uppercasecount':0, 'lowercasecount':1}

    for character in input_string:
        if character.isupper():
            d['uppercasecount']+=1
        if character.islower():
            d['lowercasecount']+=1
    return d

print(up_low("HfdfgsFDFGHJ"))


